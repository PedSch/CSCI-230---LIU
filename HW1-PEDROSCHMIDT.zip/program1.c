#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/* Pedro Schmidt 
CSCI 230 ONLINE
Program 1 part B
transposing a 4x5 2D Array in a 5x4 2D array
*/

int main(void) {
  
   int A[4][5] = {{-1,-2,-3,-4,-5},{-6},{-11},{-16}};
   int i,j;
   int transpose[5][4];
  
   for(i=0;i<4;i++)
   {
       for(j=0;j<5;j++)
       {
           if(i>0 && j>0)
           {
               A[i][j] = A[i-1][j] * A[i][j-1];
           }
       }
   }
  
  // j =
 char output[100];
 char temp[6];
for (int j=1; j < 6 ; j++)
    {
     sprintf(temp, "%6d" , j);
     strcat(output, temp);
     }
    printf(" j=" "%s\n", output);

    printf("---+----------------\n");
   // print elements of array A rowwise
  
  
       for(i=0;i<4;i++)
       {
        printf("%d |" , i);
       for(j=0;j<5;j++)
       {
           printf("%10d\t",A[i][j]);
       }
       printf("\n");
       }
      }
